// This project is to test DDR2 Memory on ANVL Board
// Switches = Address
// DIP Switches = Data
// LEDS = Display the data read
// BTN0 = Reset

1) Set switches to any bit pattern 
2) Set DIP switches to any bit pattern
3) The dip switches bit patterns 
   will be read and written to the address
   location = {0, switches}
4) The location is immediately read
   and the value displayed on LEDs
