/*
Name: Claude Watson
Description: to split project 9 into two source files and one header file. 
*/

#ifndef READ_LINE_H
#define READ_LINE_H

int read_line(char str[], int n);

#endif /* READ_LINE_H */
